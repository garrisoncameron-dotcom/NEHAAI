Admin Delete + Sheets to Supabase Migration

1) GitHub upload
Upload/replace these files at the root of garrisoncameron-dotcom/NEHAAI on main:
- github-root/admin.html
- github-root/admin.js
- github-root/admin.css

Suggested commit message:
Add admin delete controls

2) Supabase Edge Function
In Supabase, open Edge Functions > app-api and replace/deploy the function source with:
- supabase-functions/app-api/index.ts

This enables:
- admin:deleteRecord for permanently deleting test records
- admin:importRows for safe one-time Google Sheets backfill without resending emails

3) Google Apps Script migration
In the existing Apps Script project connected to the Google Sheet, add/paste:
- apps-script/google-sheets-to-supabase-migration.gs

Set MIGRATION_ADMIN_TOKEN to the same admin passcode/token used for the admin console.
Run previewSupabaseMigration_ first.
Then run migrateSheetsToSupabase_ once.

The migration reads existing Sheets tabs, sends records to Supabase in batches, and uses dedupe keys so re-running should skip already imported rows.
