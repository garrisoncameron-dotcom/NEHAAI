// One-time migration helper for copying existing NEHA Google Sheet rows into Supabase.
// Paste this into the existing Apps Script project, set ADMIN_TOKEN below, run
// previewSupabaseMigration_ first, then run migrateSheetsToSupabase_.

const MIGRATION_ADMIN_ENDPOINT = "https://hjtyqkmjmilyitrmuief.supabase.co/functions/v1/app-api";
const MIGRATION_ADMIN_TOKEN = "PASTE_ADMIN_TOKEN_HERE";
const MIGRATION_DRY_RUN = false;

function previewSupabaseMigration_() {
  const result = buildSupabaseMigrationBatches_();
  Logger.log(JSON.stringify(result.summary, null, 2));
  return result.summary;
}

function migrateSheetsToSupabase_() {
  if (!MIGRATION_ADMIN_TOKEN || MIGRATION_ADMIN_TOKEN === "PASTE_ADMIN_TOKEN_HERE") {
    throw new Error("Set MIGRATION_ADMIN_TOKEN before running migration.");
  }
  const { batches, summary } = buildSupabaseMigrationBatches_();
  Logger.log(`Prepared ${summary.totalRows} rows across ${batches.length} batches.`);
  if (MIGRATION_DRY_RUN) {
    Logger.log("MIGRATION_DRY_RUN is true. No rows sent.");
    return summary;
  }

  const results = [];
  batches.forEach((batch) => {
    const response = UrlFetchApp.fetch(MIGRATION_ADMIN_ENDPOINT, {
      method: "post",
      contentType: "application/json",
      muteHttpExceptions: true,
      headers: {
        "x-admin-token": MIGRATION_ADMIN_TOKEN,
        "Authorization": `Bearer ${MIGRATION_ADMIN_TOKEN}`
      },
      payload: JSON.stringify({
        action: "admin:importRows",
        table: batch.table,
        dedupeKeys: batch.dedupeKeys,
        rows: batch.rows
      })
    });
    const text = response.getContentText();
    const parsed = JSON.parse(text || "{}");
    Logger.log(`${batch.table}: ${text}`);
    if (response.getResponseCode() >= 400 || parsed.ok === false) {
      throw new Error(`Migration failed for ${batch.table}: ${text}`);
    }
    results.push(parsed);
  });
  return { summary, results };
}

function buildSupabaseMigrationBatches_() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  const jobs = [
    rowsJob_(ss, SHEET_NAME, "lead_captures", ["email", "submitted_at"], mapLeadRow_),
    rowsJob_(ss, DEMO_SHEET_NAME, "demo_requests", ["email", "requested_at"], mapDemoRow_),
    rowsJob_(ss, TRIVIA_SHEET_NAME, "trivia_scores", ["email", "board_id", "completed_at", "score"], mapTriviaRow_),
    rowsJob_(ss, DRINK_SHEET_NAME, "drink_redemptions", ["redemption_code"], mapDrinkRow_),
    rowsJob_(ss, COMMUNITY_SHEET_NAME, "community_posts", ["post_id"], mapCommunityPostRow_),
    rowsJob_(ss, COMMUNITY_REPLIES_SHEET_NAME, "community_replies", ["reply_id"], mapCommunityReplyRow_),
    rowsJob_(ss, SESSION_QUESTIONS_SHEET_NAME, "session_questions", ["question_id"], mapSessionQuestionRow_),
    rowsJob_(ss, SESSION_REPLIES_SHEET_NAME, "session_question_replies", ["reply_id"], mapSessionReplyRow_),
    rowsJob_(ss, SCHEDULE_EMAIL_SHEET_NAME, "schedule_email_requests", ["email", "requested_at"], mapScheduleEmailRow_),
    rowsJob_(ss, SESSION_NOTES_EMAIL_SHEET_NAME, "session_notes_email_requests", ["recipient_email", "session_id", "requested_at"], mapSessionNotesEmailRow_),
    rowsJob_(ss, SCHEDULE_SYNC_SHEET_NAME, "synced_schedules", ["email", "synced_at"], mapScheduleSyncRow_),
    rowsJob_(ss, ALERTS_SHEET_NAME, "app_alerts", ["title", "message", "view"], mapAlertRow_)
  ].filter(Boolean);

  const batches = [];
  jobs.forEach((job) => {
    chunkRows_(job.rows, 200).forEach((rows) => {
      batches.push({ table: job.table, dedupeKeys: job.dedupeKeys, rows });
    });
  });

  return {
    batches,
    summary: {
      totalRows: jobs.reduce((sum, job) => sum + job.rows.length, 0),
      tables: jobs.map((job) => ({ table: job.table, rows: job.rows.length }))
    }
  };
}

function rowsJob_(ss, sheetName, table, dedupeKeys, mapper) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() <= 1) return { table, dedupeKeys, rows: [] };
  const rows = sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).getValues()
    .map((row, index) => mapper(row, index + 2))
    .filter(Boolean);
  return { table, dedupeKeys, rows };
}

function mapLeadRow_(row) {
  const email = emailValue_(row[3]);
  if (!email) return null;
  return {
    full_name: textValue_(row[1]),
    agency: textValue_(row[2]),
    email,
    submitted_at: isoValue_(row[4] || row[0]),
    source: textValue_(row[5]),
    page_url: textValue_(row[6]),
    created_at: isoValue_(row[0])
  };
}

function mapDemoRow_(row) {
  const email = emailValue_(row[3]);
  if (!email) return null;
  return {
    full_name: textValue_(row[1]),
    agency: textValue_(row[2]),
    email,
    phone: textValue_(row[4]),
    state: textValue_(row[5]),
    notes: textValue_(row[6]),
    requested_at: isoValue_(row[7] || row[0]),
    source: textValue_(row[8]),
    page_url: textValue_(row[9]),
    created_at: isoValue_(row[0])
  };
}

function mapTriviaRow_(row) {
  const email = emailValue_(row[4]);
  if (!email) return null;
  return {
    display_name: textValue_(row[1]) || displayName_(row[2]),
    full_name: textValue_(row[2]),
    agency: textValue_(row[3]),
    email,
    score: Number(row[5] || 0),
    total: Number(row[6] || 12),
    achievement: textValue_(row[7]),
    hints_used: Number(row[8] || 0),
    completed_at: isoValue_(row[9] || row[0]),
    source: textValue_(row[10]),
    page_url: textValue_(row[11]),
    board_id: textValue_(row[12]) || "food",
    board_name: textValue_(row[13]) || "Food Code",
    created_at: isoValue_(row[0])
  };
}

function mapDrinkRow_(row) {
  const code = textValue_(row[1]);
  if (!code) return null;
  return {
    redemption_code: code,
    display_name: textValue_(row[2]) || displayName_(row[3]),
    full_name: textValue_(row[3]),
    agency: textValue_(row[4]),
    email: emailValue_(row[5]),
    issued_at: isoValue_(row[6] || row[0]),
    redeemed_at: isoValue_(row[6] || row[0]),
    status: textValue_(row[7]) || "Issued",
    served_at: isoOrBlank_(row[8]),
    served_by: textValue_(row[9]),
    source: textValue_(row[10]),
    page_url: textValue_(row[11]),
    user_agent: textValue_(row[12]),
    created_at: isoValue_(row[0])
  };
}

function mapCommunityPostRow_(row, rowNumber) {
  const title = textValue_(row[2]);
  const message = textValue_(row[3]);
  if (!title || !message) return null;
  return {
    post_id: textValue_(row[14]) || stableId_("post", rowNumber, title, message),
    category: normalizeCommunityCategory_(row[1]),
    title,
    message,
    image_url: textValue_(row[4]),
    display_name: textValue_(row[5]) || displayName_(row[6]),
    full_name: textValue_(row[6]),
    agency: textValue_(row[7]),
    email: emailValue_(row[8]),
    share_email: yesValue_(row[9]),
    posted_at: isoValue_(row[10] || row[0]),
    source: textValue_(row[11]),
    page_url: textValue_(row[12]),
    status: textValue_(row[13]) || "Visible",
    created_at: isoValue_(row[0])
  };
}

function mapCommunityReplyRow_(row, rowNumber) {
  const postId = textValue_(row[1]);
  const message = textValue_(row[2]);
  if (!postId || !message) return null;
  return {
    reply_id: stableId_("reply", rowNumber, postId, message, row[7]),
    post_id: postId,
    message,
    display_name: textValue_(row[3]) || displayName_(row[4]),
    full_name: textValue_(row[4]),
    agency: textValue_(row[5]),
    email: emailValue_(row[6]),
    posted_at: isoValue_(row[7] || row[0]),
    source: textValue_(row[8]),
    page_url: textValue_(row[9]),
    status: textValue_(row[10]) || "Visible",
    created_at: isoValue_(row[0])
  };
}

function mapSessionQuestionRow_(row, rowNumber) {
  const sessionId = textValue_(row[2]);
  const title = textValue_(row[5]);
  const message = textValue_(row[6]);
  if (!sessionId || !title || !message) return null;
  return {
    question_id: textValue_(row[1]) || stableId_("question", rowNumber, sessionId, title, message),
    session_id: sessionId,
    session_title: textValue_(row[3]),
    session_time: textValue_(row[4]),
    title,
    message,
    display_name: textValue_(row[7]) || displayName_(row[8]),
    full_name: textValue_(row[8]),
    agency: textValue_(row[9]),
    email: emailValue_(row[10]),
    posted_at: isoValue_(row[11] || row[0]),
    source: textValue_(row[12]),
    page_url: textValue_(row[13]),
    status: textValue_(row[14]) || "Visible",
    created_at: isoValue_(row[0])
  };
}

function mapSessionReplyRow_(row, rowNumber) {
  const questionId = textValue_(row[1]);
  const sessionId = textValue_(row[2]);
  const message = textValue_(row[3]);
  if (!questionId || !sessionId || !message) return null;
  return {
    reply_id: stableId_("reply", rowNumber, questionId, message, row[8]),
    question_id: questionId,
    session_id: sessionId,
    message,
    display_name: textValue_(row[4]) || displayName_(row[5]),
    full_name: textValue_(row[5]),
    agency: textValue_(row[6]),
    email: emailValue_(row[7]),
    posted_at: isoValue_(row[8] || row[0]),
    source: textValue_(row[9]),
    page_url: textValue_(row[10]),
    status: textValue_(row[11]) || "Visible",
    created_at: isoValue_(row[0])
  };
}

function mapScheduleEmailRow_(row) {
  const email = emailValue_(row[3]);
  if (!email) return null;
  return {
    full_name: textValue_(row[1]),
    agency: textValue_(row[2]),
    email,
    recipient_email: email,
    schedule_items: jsonValue_(row[5], []),
    requested_at: isoValue_(row[6] || row[0]),
    source: textValue_(row[7]),
    page_url: textValue_(row[8]),
    created_at: isoValue_(row[0])
  };
}

function mapSessionNotesEmailRow_(row) {
  const recipient = emailValue_(row[4]);
  if (!recipient) return null;
  return {
    full_name: textValue_(row[1]),
    agency: textValue_(row[2]),
    email: emailValue_(row[3]),
    recipient_email: recipient,
    session_id: textValue_(row[5]),
    session_title: textValue_(row[6]),
    notes: textValue_(row[10]),
    requested_at: isoValue_(row[11] || row[0]),
    source: textValue_(row[12]),
    page_url: textValue_(row[13]),
    created_at: isoValue_(row[0])
  };
}

function mapScheduleSyncRow_(row) {
  const email = emailValue_(row[3]);
  if (!email) return null;
  return {
    email,
    schedule_items: {
      attendingCount: Number(row[4] || 0),
      watchingCount: Number(row[5] || 0),
      attending: jsonValue_(row[6], []),
      watching: jsonValue_(row[7], [])
    },
    synced_at: isoValue_(row[8] || row[0]),
    source: textValue_(row[9]),
    page_url: textValue_(row[10]),
    created_at: isoValue_(row[0])
  };
}

function mapAlertRow_(row) {
  const title = textValue_(row[2]);
  const message = textValue_(row[3]);
  if (!title || !message) return null;
  return {
    title,
    message,
    button_label: textValue_(row[4]) || "Open",
    view: textValue_(row[5]) || "my",
    active: yesValue_(row[0]),
    starts_at: isoOrBlank_(row[6]),
    ends_at: isoOrBlank_(row[7]),
    priority: Number(row[8] || 0)
  };
}

function chunkRows_(rows, size) {
  const chunks = [];
  for (let index = 0; index < rows.length; index += size) chunks.push(rows.slice(index, index + size));
  return chunks;
}

function textValue_(value) {
  return String(value == null ? "" : value).trim();
}

function emailValue_(value) {
  const email = textValue_(value).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) ? email : "";
}

function yesValue_(value) {
  return ["yes", "true", "1", "active", "visible"].includes(textValue_(value).toLowerCase());
}

function isoValue_(value) {
  const date = value instanceof Date ? value : new Date(value || Date.now());
  return isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
}

function isoOrBlank_(value) {
  if (!value) return "";
  const date = value instanceof Date ? value : new Date(value);
  return isNaN(date.getTime()) ? "" : date.toISOString();
}

function jsonValue_(value, fallback) {
  try {
    const parsed = JSON.parse(textValue_(value));
    return parsed || fallback;
  } catch (error) {
    return fallback;
  }
}

function stableId_(prefix, rowNumber) {
  const seed = Array.prototype.slice.call(arguments, 2).map(textValue_).join("|");
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, `${prefix}|${rowNumber}|${seed}`);
  const hex = digest.map((byte) => {
    const unsigned = (byte + 256) % 256;
    return (`0${unsigned.toString(16)}`).slice(-2);
  }).join("").slice(0, 24);
  return `${prefix}-${hex}`;
}
